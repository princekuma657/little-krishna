LittleKrishna.com — demo package

Package: Kolkata To Delhi Grand Chord
Route: kolkata-delhi-grand-chord

This archive is a real, downloadable demo artifact served through the
LittleKrishna backend authorization pipeline. Production archives are
delivered from controlled storage after the same authorization checks.

Only distribute files that LittleKrishna owns or is authorized to distribute.