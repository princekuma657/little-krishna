LittleKrishna.com — demo package

Package: WDM-3 Diesel Locomotive
Route: wdm3-diesel-locomotive

This archive is a real, downloadable demo artifact served through the
LittleKrishna backend authorization pipeline. Production archives are
delivered from controlled storage after the same authorization checks.

Only distribute files that LittleKrishna owns or is authorized to distribute.